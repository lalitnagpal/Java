package com.beam.ingest;

import org.apache.avro.Schema;
import org.apache.avro.generic.GenericRecord;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.io.FileIO;
import org.apache.beam.sdk.io.TextIO;
import org.apache.beam.sdk.io.parquet.ParquetIO;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.parquet.hadoop.metadata.CompressionCodecName;

import com.beam.ingest.options.IngestOptions;

public class IngestBeamer {

	public static final Schema SCHEMA = null;
	public static final String schemaString = null;
    // public static final org.apache.avro.Schema SCHEMA$ = new org.apache.avro.Schema.Parser().parse("{\"type\":\"record\",\"name\":\"Employee\",\"namespace\":\"com.sample.beam.df.shared\",\"fields\":[{\"name\":\"id\",\"type\":[\"int\",\"null\"]},{\"name\":\"bday\",\"type\":{\"type\":\"int\",\"logicalType\":\"date\"}},{\"name\":\"firstName\",\"type\":[\"string\",\"null\"]},{\"name\":\"lastName\",\"type\":[\"string\",\"null\"]},{\"name\":\"gender\",\"type\":[\"string\",\"null\"]},{\"name\":\"dept\",\"type\":[\"string\",\"null\"]},{\"name\":\"hireDate\",\"type\":{\"type\":\"int\",\"logicalType\":\"date\"}}]}");
	
	public static void main(String[] args) {
		PipelineOptions options = PipelineOptionsFactory.as(IngestOptions.class);
		IngestOptions iOptions = options.as(IngestOptions.class);
		Pipeline pipeline = Pipeline.create(iOptions);
		
		SCHEMA = new Schema.Parser().parse(iOptions.getSchema());
		
		pipeline.apply( TextIO.read().from(iOptions.getSourceLocation()))
		 		.apply( FileIO.<GenericRecord>write()
				 	   .via(ParquetIO.sink(SCHEMA))
				 	   .to(iOptions.getDestinationLocation())
				 	   .withSuffix(".parquet"));

	}

}
