package com.beam.ingest.functions;

import org.apache.avro.Schema;
import org.apache.avro.Schema.Field;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.generic.GenericRecordBuilder;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.commons.logging.Log;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.Days;
import org.joda.time.LocalDate;
import org.joda.time.MutableDateTime;

import com.beam.ingest.domain.Employee;


public static class EmployeeToGenericRecordFn extends DoFn<Employee, GenericRecord>{
		@ProcessElement
		public void processElement(ProcessContext c) {
			
			Schema schema = Employee.getClassSchema();
			GenericRecordBuilder builder=new GenericRecordBuilder(schema);
			Employee e = c.element();
			
			for(Field f : schema.getFields())
			{
//				Log.info("Field is:"+f.name());
				if(e.get(f.name()) instanceof org.joda.time.LocalDate)
				{
					DateTime dt = ((LocalDate)e.get(f.name())).toDateTimeAtCurrentTime(DateTimeZone.UTC);
					MutableDateTime epoch = new MutableDateTime(0l, DateTimeZone.UTC);
					Days days = Days.daysBetween(epoch, dt);
					builder.set(f.name(), days.getDays());
				}
				else
					builder.set(f.name(), e.get(f.name()));
			}
			
			c.output(builder.build());
		}
}
