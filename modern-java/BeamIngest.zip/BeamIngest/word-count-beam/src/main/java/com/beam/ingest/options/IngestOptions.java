package com.beam.ingest.options;

import org.apache.beam.sdk.options.Default;
import org.apache.beam.sdk.options.Description;
import org.apache.beam.sdk.options.PipelineOptions;

public interface IngestOptions extends PipelineOptions {

	@Description("Source location")
	@Default.String("../../data")
	String getSourceLocation();
	void setSourceLocation();
	
	@Description("Destination location")
	@Default.String("../../data")
	String getDestinationLocation();
	void setDestinationLocation();
	
	@Description("Schema for Parquet")
	@Default.String("../../data")
	String getSchema();
	void setSchema();
	
	
	
}
