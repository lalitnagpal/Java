package com.beam.ingest.domain;

public class Employee {

}
